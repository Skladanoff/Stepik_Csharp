﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsBalls
{
    class SimpleBall
    {
        protected Form frm;
        protected int x = 100;
        protected int y = 100;
        protected int vx, vy;
        protected int size = 100;
        protected Brush b = Brushes.Red;
        Brush BackColor;
        Rectangle rec;
        Graphics g;

        public SimpleBall(Form f)
        {
            frm = f;
            g = frm.CreateGraphics();
            BackColor = new SolidBrush(frm.BackColor);
            vx = 10;
            vy = 10;
        }

        public void Draw()
        {      
            rec = new Rectangle(x-size/2, y-size/2, size, size);  
            g.FillEllipse(b, rec);
        }

        public void Go()
        {
            x += vx;
            y += vy;
        }

        public void Erase()
        {
            rec = new Rectangle(x - size / 2, y - size / 2, size, size);
            g.FillEllipse(BackColor, rec);
        }
    }
    class SimpleRandomBall:SimpleBall
    {

        Random rnd = new Random();

        public SimpleRandomBall(Form f):base(f)
        {
            x = rnd.Next(0, frm.ClientSize.Width);
            y = rnd.Next(0, frm.ClientSize.Height);
            size = rnd.Next(1, 100);
            b = new SolidBrush(Color.FromArgb(rnd.Next(1, 255), rnd.Next(1, 255), rnd.Next(1, 255), rnd.Next(1, 255)));
            vx = rnd.Next(-10, 10);
            vy = rnd.Next(-10, 10);
        }

    }

    class SimpleGreenBall:SimpleRandomBall
    {

        public SimpleGreenBall(Form f):base(f)
        {
            b = Brushes.Green;

        }

    }
    class SimplePointBall:SimpleBall
    {

        public SimplePointBall(Form f, int x, int y):base(f)
        {        
            this.x = x;
            this.y = y;
        }

    }

    class SimplePointRandomColorBall: SimplePointBall
    {
        public SimplePointRandomColorBall(Form f, int x, int y) : base(f, x, y)
        {
            Random rnd = new Random();
            b = new SolidBrush(Color.FromArgb(255, rnd.Next(0, 255), rnd.Next(0, 255), rnd.Next(0, 255)));
        }
    }

    class SimplePointColorBall : SimplePointBall
    {

        public SimplePointColorBall(Form f, int x, int y) : base(f, x, y)
        {
            b = Brushes.DarkCyan;
        }

    }
}
