﻿namespace WindowsFormsBalls
{
    partial class FormSampleBallClass
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSampleCircle = new System.Windows.Forms.Button();
            this.btnDrawSimpleGreenCircle = new System.Windows.Forms.Button();
            this.btnMoveGreenCircle = new System.Windows.Forms.Button();
            this.btnMoveRandomCircle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSampleCircle
            // 
            this.btnSampleCircle.Location = new System.Drawing.Point(531, 85);
            this.btnSampleCircle.Name = "btnSampleCircle";
            this.btnSampleCircle.Size = new System.Drawing.Size(193, 23);
            this.btnSampleCircle.TabIndex = 0;
            this.btnSampleCircle.Text = "Нарисовать случайный кружок";
            this.btnSampleCircle.UseVisualStyleBackColor = true;
            this.btnSampleCircle.Click += new System.EventHandler(this.btnSampleCircle_Click);
            // 
            // btnDrawSimpleGreenCircle
            // 
            this.btnDrawSimpleGreenCircle.Location = new System.Drawing.Point(531, 224);
            this.btnDrawSimpleGreenCircle.Name = "btnDrawSimpleGreenCircle";
            this.btnDrawSimpleGreenCircle.Size = new System.Drawing.Size(193, 23);
            this.btnDrawSimpleGreenCircle.TabIndex = 1;
            this.btnDrawSimpleGreenCircle.Text = "Нарисовать зеленый кружок";
            this.btnDrawSimpleGreenCircle.UseVisualStyleBackColor = true;
            this.btnDrawSimpleGreenCircle.Click += new System.EventHandler(this.btnDrawSimpleGreenCircle_Click);
            // 
            // btnMoveGreenCircle
            // 
            this.btnMoveGreenCircle.Location = new System.Drawing.Point(531, 253);
            this.btnMoveGreenCircle.Name = "btnMoveGreenCircle";
            this.btnMoveGreenCircle.Size = new System.Drawing.Size(193, 23);
            this.btnMoveGreenCircle.TabIndex = 2;
            this.btnMoveGreenCircle.Text = "Двигать зеленый кружок";
            this.btnMoveGreenCircle.UseVisualStyleBackColor = true;
            this.btnMoveGreenCircle.Click += new System.EventHandler(this.btnMoveGreenCircle_Click);
            // 
            // btnMoveRandomCircle
            // 
            this.btnMoveRandomCircle.Location = new System.Drawing.Point(531, 114);
            this.btnMoveRandomCircle.Name = "btnMoveRandomCircle";
            this.btnMoveRandomCircle.Size = new System.Drawing.Size(193, 23);
            this.btnMoveRandomCircle.TabIndex = 3;
            this.btnMoveRandomCircle.Text = "Двигать случайный кружок";
            this.btnMoveRandomCircle.UseVisualStyleBackColor = true;
            // 
            // FormSampleBallClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMoveRandomCircle);
            this.Controls.Add(this.btnMoveGreenCircle);
            this.Controls.Add(this.btnDrawSimpleGreenCircle);
            this.Controls.Add(this.btnSampleCircle);
            this.Name = "FormSampleBallClass";
            this.Text = "Форма Простой шарик";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormSampleBallClass_MouseDown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSampleCircle;
        private System.Windows.Forms.Button btnDrawSimpleGreenCircle;
        private System.Windows.Forms.Button btnMoveGreenCircle;
        private System.Windows.Forms.Button btnMoveRandomCircle;
    }
}

