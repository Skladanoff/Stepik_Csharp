﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsBalls
{
    public partial class FormSampleBallClass : Form
    {
        SimpleBall ball;
        public FormSampleBallClass()
        {
            InitializeComponent();
        }


        private void btnSampleCircle_Click(object sender, EventArgs e)
        {
            ball = new SimpleRandomBall(this);
            ball.Draw();
        }

        private void btnDrawSimpleGreenCircle_Click(object sender, EventArgs e)
        {
            ball = new SimpleGreenBall(this);
            ball.Draw();
        }

        private void FormSampleBallClass_MouseDown(object sender, MouseEventArgs e)
        {
            ball = new SimplePointColorBall(this, e.X, e.Y);
            ball.Draw();
        }

        private void btnMoveGreenCircle_Click(object sender, EventArgs e)
        {
            ball.Erase();
            ball.Go();
            ball.Draw();
        }
    }

}
